# Big Code Changes Workflow

Use for large migrations or refactors affecting >10 files.

## Guardrails
- **Before each step**: State the migration goal in one line.
- **Batch execution**: Apply ONLY patterns from `PATTERN_MAPPING.md`; flag new patterns.
- **Scope check**: List files touched per batch; flag any outside batch scope.

## Step 1: Assess Scope
**Goal**: Create `SCOPE_ASSESSMENT.md`.

1.  Search for all affected files.
2.  Categorize by complexity (Simple/Medium/Complex).
3.  Create `SCOPE_ASSESSMENT.md`.

// turbo
## Step 2: Pattern Mapping
**Goal**: Create `PATTERN_MAPPING.md`.

1.  **RE-ANCHOR**: Read `SCOPE_ASSESSMENT.md`. State the goal in one line.
2.  Analyze one representative file from each category.
3.  Create `PATTERN_MAPPING.md` (Old -> New patterns).
4.  Define Migration Checklist.

// turbo
## Step 3: Batch Planning
**Goal**: Create `BATCH_PLAN.md`.

1.  Create `BATCH_PLAN.md` breaking work into batches of 5-10 files.
2.  Define **Rollback Points** (git tags) for each batch.

## Step 4: Plan Approval (STOP POINT)
**Goal**: User approves the batch plan.

1.  **STOP**: Review `PATTERN_MAPPING.md` and `BATCH_PLAN.md`.
2.  Approve to start Batch 1.

## Step 5: Migrate Batch
**Goal**: Execute migration for a batch.

1.  **RE-ANCHOR**: Read `PATTERN_MAPPING.md` and `BATCH_PLAN.md`. State: Current batch, files in scope.
2.  **Constraint**: Apply ONLY patterns from mapping.
3.  Migrate files in current batch.
4.  **Phase Checkpoint**:
    - Files modified: [list]. Any outside batch? [Yes/No]
    - New patterns found (not in mapping)? [Yes/No - STOP if Yes]
    - Is this approach different from any previously failed attempts? [Yes/No]
    - Verify imports, types, tests.
// turbo
5.  **Auto-Test**:
    - For each modified method: check if test exists.
    - If exists: Update test to match new business logic (do NOT remove/simplify cases).
    - If not exists: Write new test to increase code coverage.
    - **Test real code**: Mock ONLY as last resort when no other option.
    - **NEVER use PowerMockito**: Use standard Mockito only.
    - **NEVER modify production code**: Design tests to work with production code as-is.
    - **Framework**: Java = TestNG; UI = Karma + Jasmine.
    - **Complex setup**: If required, implement full setup. If unclear, ASK user.
    - Report: Tests added/updated: [list]

// turbo
## Step 6: Verify Against Plan
**Goal**: Ensure nothing from the plan was missed.

1.  **Auto-Verify**:
    - Re-read `BATCH_PLAN.md` and `PATTERN_MAPPING.md`.
    - For each file in batch plan: Read the actual implemented code and verify patterns applied.
    - Compare actual code changes vs expected patterns from `PATTERN_MAPPING.md`.
    - Verify: All files from current batch modified? [Yes/No with file list]
    - Verify: All patterns from mapping applied in actual code? [Yes/No with pattern list]
    - Verify: All checklist items completed in actual implementation? [Yes/No with item list]
    - Report: Missing items [list with file:line references] or COMPLETE.
2.  If successful, create git tag for batch completion.
3.  **Loop**: Ask to proceed to next batch.
