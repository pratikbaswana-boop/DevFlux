# Complex Issue Resolution Workflow

This workflow automates the 8-step process for resolving complex issues (bugs, race conditions, etc.).
It chains the initial analysis steps to save time, but enforces "Stop and Ask" at critical decision points.

## Guardrails
- **Before each step**: State the original issue in one line.
- **Claims require evidence**: Cite `[file:line]` for any assertion.
- **Implementation steps**: List files touched; flag any outside plan scope.

## Step 1: Component Inventory
**Goal**: Create `INVENTORY.md` to map all involved code.

1.  Search the codebase for files related to the issue defined by the user.
2.  Create `INVENTORY.md` containing:
    *   Classes/Methods Involved
    *   Shared State
    *   External Dependencies
    *   Configuration
    *   Libraries
    *   **Impact Map** (What breaks if X changes?)
3.  Report completion.

// turbo
## Step 2: Flow Analysis
**Goal**: Create `FLOW_ANALYSIS.md` to trace data execution.

1.  **RE-ANCHOR**: Read `INVENTORY.md`. State the issue in one line.
2.  Create `FLOW_ANALYSIS.md` containing:
    *   Data Entry Points
    *   Step-by-Step Flow (Input -> Process -> Output -> Side Effects)
    *   Threading Model (Concurrency, Shared State)
    *   Business Logic Rules
3.  Mark unclear items as `[UNCLEAR]`.

## Step 3: Gather Issue Context (STOP POINT)
**Goal**: Collect additional context from the user before generating hypotheses.

1.  **STOP**: Ask the user the following questions:
    *   **Frequency**: How often does this issue occur? (Always, Intermittent, Rare)
    *   **Scenario**: What specific scenario/conditions trigger this issue?
    *   **Existing Findings**: Does the dev team already have any findings, suspicions, or prior investigation notes?
2.  Document the answers in `HYPOTHESES.md` under a "Context" section.
3.  **Do not proceed** until the user provides this context.

// turbo
## Step 4: Generate Hypotheses
**Goal**: Create `HYPOTHESES.md` to identify root causes.

1.  **RE-ANCHOR**: Read `INVENTORY.md`, `FLOW_ANALYSIS.md`, and user context. State the issue in one line.
2.  Generate `HYPOTHESES.md` containing at least 3 hypotheses:
    *   Theory & Mechanism
    *   Evidence For & Against (cite `[file:line]`)
    *   Verification Steps
    *   Likelihood
3.  Recommended Investigation Order.

// turbo
## Step 5: Validate Hypotheses Against Code
**Goal**: Verify each hypothesis by tracing through the actual codebase.

1.  For each hypothesis:
    *   Search the codebase for the specific code paths mentioned.
    *   Verify if the theoretical mechanism is actually possible in the code.
    *   Check if the issue scenario matches the code behavior.
    *   Mark hypothesis as **VALIDATED** or **INVALIDATED** with evidence.
2.  Update `HYPOTHESES.md` with validation results.
3.  Rank validated hypotheses by likelihood based on code evidence.

## Step 6: User Confirmation (STOP POINT)
**Goal**: Confirm the root cause before planning.

1.  **STOP**: Present validated hypotheses to the user.
2.  Ask the user to confirm which hypothesis is the root cause or if further investigation is needed.
3.  **Do not proceed** until the user explicitly confirms a root cause (e.g., "Confirmed: Hypothesis 1").

## Step 7: Implementation Plan
**Goal**: Create `IMPLEMENTATION_PLAN.md`.

1.  **RE-ANCHOR**: Read `INVENTORY.md`, `FLOW_ANALYSIS.md`, confirmed root cause. State root cause in one line.
2.  Create `IMPLEMENTATION_PLAN.md` containing:
    *   Overview & **Definition of Done**
    *   **Do Not Touch List** (Crucial!)
    *   Phased Approach (if >300 lines)
    *   For each phase: Files to Modify, New Files, Dependencies, Tests.
    *   **Rollback Points** (Git tags/revert commands).
3.  **STOP**: Ask user to review and approve the plan.

## Step 8: Implementation & Verification
**Goal**: Execute the plan in phases.

1.  **RE-ANCHOR**: Re-read `IMPLEMENTATION_PLAN.md`. State: Current phase, what it does, what remains.
2.  **Constraint Check**: Re-read the "Do Not Touch" list.
3.  **Phase Execution**:
    *   Implement exactly as planned.
    *   **Phase Checkpoint**:
        - Files modified: [list]. Any outside plan? [Yes/No]
        - "Do Not Touch" violations? [Yes/No]
        - Is this approach different from any previously failed attempts? [Yes/No]
// turbo
    *   **Auto-Test**:
        - For each modified method: check if test exists.
        - If exists: Update test to match new business logic (do NOT remove/simplify cases).
        - If not exists: Write new test to increase code coverage.
        - **Test real code**: Mock ONLY as last resort when no other option.
        - **NEVER use PowerMockito**: Use standard Mockito only.
        - **NEVER modify production code**: Design tests to work with production code as-is.
        - **Framework**: Java = TestNG; UI = Karma + Jasmine.
        - **Complex setup**: If required, implement full setup. If unclear, ASK user.
        - Report: Tests added/updated: [list]

// turbo
## Step 9: Verify Against Plan
**Goal**: Ensure nothing from the plan was missed.

1.  **Auto-Verify**:
    - Re-read `IMPLEMENTATION_PLAN.md`.
    - For each file in plan: Read the actual implemented code and verify changes match plan.
    - Compare actual implementation vs planned changes in `IMPLEMENTATION_PLAN.md`.
    - Verify: All files for current phase modified? [Yes/No with file list]
    - Verify: All new files created? [Yes/No with file list]
    - Verify: All dependencies added in actual code? [Yes/No with dependency list]
    - Verify: Definition of Done criteria met in actual implementation? [Yes/No with criteria list]
    - Report: Missing items [list with file:line references] or COMPLETE.
2.  **Loop**: If more phases exist, ask user for approval to proceed to next phase, then repeat.
