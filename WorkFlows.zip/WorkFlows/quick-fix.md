# Quick Fix Workflow (AI Finds Solution)

Use this when you know the issue but need AI to find the root cause and fix it.

## Guardrails
- **Claims require evidence**: Cite `[file:line]` for root cause.
- **Implementation**: Change ONLY proposed lines; flag any additions.

## Step 1: Analyze and Propose
**Goal**: Identify root cause and propose a minimal fix.

1.  Read relevant code.
2.  Identify root cause.
3.  Propose MINIMAL fix.
4.  Output:
    *   ROOT CAUSE
    *   FILE
    *   CHANGE NEEDED
    *   LINES AFFECTED
    *   RISK

## Step 2: Approval (STOP POINT)
**Goal**: User approves the proposal.

1.  **STOP**: Review the proposal.
2.  If approved, proceed to implementation.
3.  If not, refine the proposal.

## Step 3: Implement Fix
**Goal**: Apply the approved fix.

1.  Implement EXACTLY what was proposed.
2.  Change ONLY the specific lines.
3.  Match existing code style.
4.  **Checkpoint**: Files modified: [list]. Any outside proposal? [Yes/No]
// turbo
5.  **Auto-Test**:
    - For each modified method: check if test exists.
    - If exists: Update test to match new business logic (do NOT remove/simplify cases).
    - If not exists: Write new test to increase code coverage.
    - **Test real code**: Mock ONLY as last resort when no other option.
    - **NEVER use PowerMockito**: Use standard Mockito only.
    - **NEVER modify production code**: Design tests to work with production code as-is.
    - **Framework**: Java = TestNG; UI = Karma + Jasmine.
    - **Complex setup**: If required, implement full setup. If unclear, ASK user.
    - Report: Tests added/updated: [list]

// turbo
## Step 4: Verify Against Proposal
**Goal**: Ensure nothing from the proposal was missed.

1.  **Auto-Verify**:
    - Re-read the proposal from Step 1.
    - Read the actual implemented code in the modified files.
    - Compare actual code changes vs proposed changes line-by-line.
    - Verify: Exact lines modified as proposed? [Yes/No with line references]
    - Verify: No additional changes made? [Yes/No with any extra changes listed]
    - Verify: Code style matches existing code? [Yes/No with style issues]
    - Report: Deviations [list with file:line references] or COMPLETE.
