# Release Upgrade Workflow

Use this when a bug appears after upgrading versions.

## Guardrails
- **Before each step**: State the broken functionality in one line.
- **Claims require evidence**: Cite `[file:line]` or diff output for assertions.
- **Implementation**: List files touched; flag any outside fix scope.

## Step 1: Analyze Version Differences
**Goal**: Create `VERSION_DIFF.md`.

1.  Run `git diff` between versions.
2.  Check dependency and config changes.
3.  Create `VERSION_DIFF.md` (Code, Dependency, Config, API changes).

// turbo
## Step 2: Impact Analysis
**Goal**: Map changes to the bug.

1.  **RE-ANCHOR**: Read `VERSION_DIFF.md`. State broken functionality in one line.
2.  Create `IMPACT_ANALYSIS.md` (cite evidence for each likelihood rating).
3.  Identify the "Most Likely Culprit".

## Step 3: Confirm Culprit (STOP POINT)
**Goal**: User confirms the root cause.

1.  **STOP**: Review `IMPACT_ANALYSIS.md`.
2.  Confirm which change is causing the issue.

## Step 4: Propose Fix Strategies
**Goal**: Create `FIX_OPTIONS.md`.

1.  Create `FIX_OPTIONS.md` with:
    *   Option A: Adapt to New Behavior.
    *   Option B: Restore Old Behavior.
    *   Recommendation.

## Step 5: Strategy Selection (STOP POINT)
**Goal**: User selects a strategy.

1.  **STOP**: Choose Option A or B.

## Step 6: Implementation
**Goal**: Implement chosen strategy.

1.  **RE-ANCHOR**: Re-read `FIX_OPTIONS.md`. State: Chosen option, what it does.
2.  Create `PRE_FIX` git tag.
3.  Implement the chosen option.
4.  **Phase Checkpoint**:
    - Files modified: [list]. Any outside fix scope? [Yes/No]
    - Is this approach different from any previously failed attempts? [Yes/No]
// turbo
5.  **Auto-Test**:
    - For each modified method: check if test exists.
    - If exists: Update test to match new business logic (do NOT remove/simplify cases).
    - If not exists: Write new test to increase code coverage.
    - **Test real code**: Mock ONLY as last resort when no other option.
    - **NEVER use PowerMockito**: Use standard Mockito only.
    - **NEVER modify production code**: Design tests to work with production code as-is.
    - **Framework**: Java = TestNG; UI = Karma + Jasmine.
    - **Complex setup**: If required, implement full setup. If unclear, ASK user.
    - Report: Tests added/updated: [list]

// turbo
## Step 7: Verify Against Strategy
**Goal**: Ensure nothing from the strategy was missed.

1.  **Auto-Verify**:
    - Re-read `FIX_OPTIONS.md` and chosen strategy.
    - Read the actual implemented code in all modified files.
    - Compare actual implementation vs chosen strategy components.
    - Verify: All components of chosen option implemented in actual code? [Yes/No with component list]
    - Verify: No unintended changes made in actual code? [Yes/No with any extra changes]
    - Verify: Broken functionality restored in actual implementation? [Yes/No with evidence]
    - Report: Missing items [list with file:line references] or COMPLETE.
