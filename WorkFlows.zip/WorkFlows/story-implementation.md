# Story Implementation Workflow

This workflow automates the process for implementing new user stories or features.
It chains the initial research and design phases but enforces approval before implementation.

## Guardrails
- **Before each step**: State the story goal in one line.
- **Pattern adherence**: Follow ONLY patterns from `CODEBASE_PATTERNS.md`.
- **Implementation**: List files touched; flag any outside `DESIGN.md` scope.

## Step 1: Learn Codebase Patterns
**Goal**: Create `CODEBASE_PATTERNS.md`.

1.  Analyze the user story provided.
2.  Find a SIMILAR existing feature in the codebase.
3.  Create `CODEBASE_PATTERNS.md` containing:
    *   Reference Feature Analyzed
    *   Architecture Pattern
    *   Naming Conventions
    *   Error Handling & Logging Patterns
    *   Existing Utilities to Reuse

// turbo
## Step 2: Create Design Document
**Goal**: Create `DESIGN.md`.

1.  **RE-ANCHOR**: Read `CODEBASE_PATTERNS.md`. State the story goal in one line.
2.  Create `DESIGN.md` containing:
    *   Components (New/Modified)
    *   Data Model & API Contract
    *   Dependencies
    *   **Definition of Done**
    *   **Decisions Log**
    *   **Do Not Touch List**
    *   Rollback Points
3.  **STOP**: Ask user to review `DESIGN.md`.

## Step 3: Design Review (STOP POINT)
**Goal**: Get approval on the design.

1.  Do not proceed until the user approves the design or requests changes.
2.  If changes are requested, update `DESIGN.md` and re-request approval.

## Step 4: Implementation Phases
**Goal**: Implement in phases.

1.  **RE-ANCHOR**: Re-read `DESIGN.md` and `CODEBASE_PATTERNS.md`. State: Current phase, what it does, what remains.
2.  **Constraint Check**: Re-read "Do Not Touch" list.
3.  **Phase Execution**:
    *   Implement Phase from `DESIGN.md`.
    *   **Phase Checkpoint**:
        - Files modified: [list]. Any outside `DESIGN.md` scope? [Yes/No]
        - "Do Not Touch" violations? [Yes/No]
        - Pattern deviations from `CODEBASE_PATTERNS.md`? [Yes/No]
        - Verify dependencies, imports, and functionality.
// turbo
    *   **Auto-Test**:
        - For each modified method: check if test exists.
        - If exists: Update test to match new business logic (do NOT remove/simplify cases).
        - If not exists: Write new test to increase code coverage.
        - **Test real code**: Mock ONLY as last resort when no other option.
        - **NEVER use PowerMockito**: Use standard Mockito only.
        - **NEVER modify production code**: Design tests to work with production code as-is.
        - **Framework**: Java = TestNG; UI = Karma + Jasmine.
        - **Complex setup**: If required, implement full setup. If unclear, ASK user.
        - Report: Tests added/updated: [list]
4.  **Loop**: Ask for approval to proceed to the next phase.

// turbo
## Step 5: Verify Against Design
**Goal**: Ensure nothing from the design was missed.

1.  **Auto-Verify**:
    - Re-read `DESIGN.md` for current phase.
    - For each component in design: Read the actual implemented code and verify implementation.
    - Compare actual implementation vs design specifications.
    - Verify: All components for phase implemented in actual code? [Yes/No with component list]
    - Verify: All files to modify updated with actual changes? [Yes/No with file list]
    - Verify: All new files created with actual content? [Yes/No with file list]
    - Verify: All dependencies added in actual code? [Yes/No with dependency list]
    - Verify: Definition of Done criteria met in actual implementation? [Yes/No with criteria list]
    - Report: Missing items [list with file:line references] or COMPLETE.

## Step 6: Verify Dependencies
**Goal**: Ensure implementation completeness.

1.  For each phase, verify:
    *   All imports exist in project.
    *   All injected beans/services exist.
    *   All called methods are accessible.
    *   All config properties exist.
2.  Report: Missing dependencies [list] or PASS.
