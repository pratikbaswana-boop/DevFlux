# Test Writing Workflow

Use for writing unit tests for a class or method.

## Guardrails
- **Pattern adherence**: Match EXACTLY the patterns from existing tests.
- **Plan adherence**: Implement ALL test cases from `TEST_PLAN.md`.
- **NEVER use PowerMockito**: Use standard Mockito only.
- **NEVER modify production code**: Design tests to work with production code as-is.

## Step 1: Analyze & Plan
**Goal**: Create `TEST_PLAN.md`.

1.  Analyze code to test.
2.  Find existing test patterns.
3.  Create `TEST_PLAN.md`:
    *   Code Analysis (branches, edge cases).
    *   Existing Patterns (framework, naming).
    *   Test Cases Needed.

## Step 2: Plan Review (STOP POINT)
**Goal**: Approve test cases.

1.  **STOP**: Review `TEST_PLAN.md`.
2.  Approve or request more cases.

## Step 3: Write Tests
**Goal**: Implement the test class.

1.  **RE-ANCHOR**: Read `TEST_PLAN.md`. State: Number of test cases to implement.
2.  Write tests matching `TEST_PLAN.md`.
3.  Match existing patterns exactly (from Reference Test File).
4.  **Testing Guidelines**:
    - For each method: check if test exists.
    - If exists: Update test to match new business logic (do NOT remove/simplify cases).
    - If not exists: Write new test to increase code coverage.
    - **Test real code**: Mock ONLY as last resort when no other option.
    - **NEVER use PowerMockito**: Use standard Mockito only.
    - **NEVER modify production code**: Design tests to work with production code as-is.
    - **Framework**: Java = TestNG; UI = Karma + Jasmine.
    - **Complex setup**: If required, implement full setup. If unclear, ASK user.
5.  Report: Tests added/updated: [list]

// turbo
## Step 4: Verify Against Plan
**Goal**: Ensure nothing from the plan was missed.

1.  **Auto-Verify**:
    - Re-read `TEST_PLAN.md`.
    - Read the actual implemented test code.
    - Compare actual test implementation vs planned test cases.
    - For each planned test: Verify it exists in actual code with correct assertions.
    - Compare Plan vs Implementation:
      | Planned Test | Implemented | Correct | File:Line |
    - Verify: All test cases from plan implemented in actual code? [Yes/No with test list]
    - Verify: All branches covered in actual tests? [Yes/No with branch list]
    - Verify: All edge cases covered in actual tests? [Yes/No with case list]
    - Report: Missing tests [list with file:line references] or COMPLETE.

## Step 5: Verify Coverage
**Goal**: Verify completeness.

1.  Check for missing branches or edge cases.
2.  **Checkpoint**: All planned tests implemented? [Yes/No]. Missing: [list or none].
